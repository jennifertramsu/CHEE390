% Ngan Jennifer Tram Su [260923530]

function y = Gn(z)

y = (4 .* (sin(z) - z.*cos(z)))./(2*z - sin(2*z));

end